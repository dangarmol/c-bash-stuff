#ifndef _MY_SIG_HANDLER
#define  _MY_SIG_HANDLER 

int create_signal_handler(sys_mbox_t* mbox);
void finish_signal_handler(void);
	
#endif
