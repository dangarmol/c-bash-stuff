#include <stdio.h>
#include <stdlib.h>
#include "archi.h"

int main(void)
{
	printf("Hola ...%d\n", VAR);
	exit(1);
}

